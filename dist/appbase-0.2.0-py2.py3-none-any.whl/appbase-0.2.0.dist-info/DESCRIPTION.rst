Appbase is the foundation for a pyQt based application including:

* save, load, autosave
* fullscreen with F11
* close-dialog
* system tray control

Home-page: http://pypi.python.org/pypi/AppBase/
Author: Karl Bedrich
Author-email: karl@bedrich.de
License: GPLv3
Description: =======================================
        AppBase - your base for app development
        =======================================
        
        Appbase is the foundation for a pyQt based application
        
        It includes:
        
        	* **Launcher.py** - a graphical launcher to view and open python sessions stored as *.pyz
        	* **Application.py** - just substitude yout QApplication this one and you get...
        		* open, save, new, timed autosave etc.
        	* **MainWindow.py** - this mainWindow gives you a predefined menubar including all features of application.py
           * **MultiWorkspaceWindow.py** - mainWindow with workspace management
           * **Server.py** - a system tray control for the mainWindow
        
        
        During the install procedure you also have the option to add a launcher in your start menu launching the Launcher.py under default conditions.
        
        The Launcher itsef is highly customable alowing different headers, logos and file types to start.
        
        v0.2, <22/12/2014> -- Initial release.
        
        
        
        Karl Bedrich 2013 - 2014
Platform: UNKNOWN
Classifier: Intended Audience :: Developers
Classifier: Intended Audience :: Science/Research
Classifier: Intended Audience :: Other Audience
Classifier: License :: OSI Approved :: GNU General Public License (GPL)
Classifier: Operating System :: OS Independent
Classifier: Programming Language :: Python
Classifier: Topic :: Scientific/Engineering :: Information Analysis
Classifier: Topic :: Scientific/Engineering :: Visualization
Classifier: Topic :: Software Development :: Libraries :: Python Modules
